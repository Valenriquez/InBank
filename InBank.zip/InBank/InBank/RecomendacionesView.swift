//
//  RecomendacionesView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
//

import SwiftUI

struct RecomendacionesView: View {
    var body: some View {
        Text("Recomendaciones")
    }
}

struct RecomendacionesView_Previews: PreviewProvider {
    static var previews: some View {
        RecomendacionesView()
    }
}
