//
//  Square.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
// Color(red: 160/255, green: 167/255, blue: 173/255)

import SwiftUI

struct Square: View {
    var body: some View {
        ZStack() {

            Rectangle()
                    .fill(Color.white)
                    .border(Color.gray, width: 8)
                    .frame(width: 300, height: 350)
            
            RoundedRectangle(cornerRadius: 50)
                .fill(Color.gray)
                .frame(width: 200, height: 80)
                .offset(y: -170)
            
            VStack {
                // Textos
                Text("NTCT")
                    .offset(y: -78)
                    .foregroundColor(.white)
                    .font(.system(size: 30))
                    .fontWeight(.bold)
                
                Text("Rendimiento")
                    .offset(y: -35)
                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))
                    .font(.system(size: 25))
                    .fontWeight(.bold)
                
                Text("X%")
                    .offset(y: -30)
                    .font(.custom("Kollektif-Bold", size: 50))
                    .foregroundColor(Color(red: 92/255, green: 102/255, blue: 112/255))
                
                Text("Diferencia con el \nmes actual")
                    .offset(y: 10)
                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))
                    .font(.system(size: 25))
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                
                Text("X%")
                    .offset(y: 15)
                    .font(.custom("Kollektif-Bold", size: 50))
                    .foregroundColor(Color(red: 92/255, green: 102/255, blue: 112/255))
            }
            .padding()
        }
        // Espaciado general
    }
}

struct Square_Previews: PreviewProvider {
    static var previews: some View {
        Square()
    }
}
