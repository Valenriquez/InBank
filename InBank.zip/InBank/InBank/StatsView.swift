//
//  FomoView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
//

import SwiftUI
import Charts

struct GraphView: View {
    let data: [Double]
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Path { path in
                    for y in stride(from: 0, through: geometry.size.height, by: 20) {
                        path.move(to: CGPoint(x: 0, y: y))
                        
                    }
                    for x in stride(from: 0, through: geometry.size.width, by: 20) {
                        path.move(to: CGPoint(x: x, y: 0))
                        
                    }
                }
                .stroke(Color.gray.opacity(0.5), lineWidth: 0.5)
                
                
                Path { path in
                    for (index, value) in data.enumerated() {
                        let x = CGFloat(index) * (geometry.size.width / CGFloat(data.count - 1))
                        let y = CGFloat(1 - value / maxValue) * geometry.size.height
                        let point = CGPoint(x: x, y: y)
                        if index == 0 {
                            path.move(to: point)
                        } else {
                            path.addLine(to: point)
                        }
                    }
                }
                .stroke(Color.gray, lineWidth: 3)
            }
            .frame(height: 300)
        }
    }
    
    private var maxValue: Double {
        return data.max() ?? 1.0
    }
}


struct GridRowView: View {
    var text: String
    
    var body: some View {
        HStack {
            Text(text)
                .font(.headline)
            Spacer()
        }
        .padding()
        .border(Color.gray, width: 1)
    }
}

struct SquareView: View {
    var value: Int
    var label: String
    
    var body: some View {
        VStack {
            Text("\(value)")
                .font(.title)
            Text(label)
                .font(.caption)
        }
        .frame(width: 175, height: 150)
        .background(Color.white)
        .border(Color.gray, width: 2)
    }
}


struct RoundedGreyTextField: View {
    @Binding var text: String
    
    var body: some View {
        TextField("Enter text here", text: $text)
            .padding()
            .background(RoundedRectangle(cornerRadius: 10).stroke(Color.gray, lineWidth: 7))
            .padding(EdgeInsets(top: 10, leading: 10, bottom: 10, trailing: 10))
    }
}


struct StatsView: View {
    
    @ObservedObject var questionnaire: QuestionnaireModel
    
    init(questionnaire: QuestionnaireModel) {
        self.questionnaire = questionnaire
    }

    
    @State private var textInput: String = ""
    @State private var sliderValue: Double = 50
    @State private var inputText: String = "6756.98"
    let closeStats: [Double] = [9.7, 7.1, 8.1, 8.9, 10.5, 8.2, 12.0, 12.5, 12.2, 9.3, 9.2]
    
    var investmentAmount: Double {
        let income = Double(inputText) ?? 0.0
        return income * (sliderValue / 100)
    }
    @State private var text1: String = ""
    @State private var text2: String = ""
    let data: [Double] = [  407.18242754,   364.14887262,   366.09979858,   341.2678705 ,
                            248.78254749,   234.15364456,   269.04225897,   235.49153392,
                            236.99700091,   238.08176575,   279.5637399 ,   250.73380501,
                            233.59553324,   264.85535554,   348.88333232,   424.46454743,
                            410.84448538,   404.40827363,   416.52577357,   434.33939819,
                            461.95441461,   642.86906128,   661.35610273,   579.5851972 ,
                            605.84863281,   643.55093482,   726.34910075,   828.06035589,
                            914.91615935,  1062.53367179,  1129.36522847,  1206.64100749,
                            1895.38352917,  2636.2043457 ,  2519.41838615,  3880.98999811,
                            4064.83631185,  5360.07160408,  7813.13297526, 15294.27098034,
                            13085.55808972,  9472.00115095,  9040.5570974 ,  8033.59663086,
                            8450.99773185,  6793.50766602,  7146.3499874 ,  6700.12994582,
                            6610.67503255,  6485.11874685,  5404.2501709 ,  3717.48834425,
                            3701.55496314,  3711.90726144,  3976.06909967,  5178.46943359,
                            7309.69413117,  9415.90017904, 10669.33615801, 10643.2483619 ,
                            9814.06787109,  8411.92916772,  8373.57241211,  7284.01304183,
                            8389.27047631,  9630.72218481,  6871.01611328,  7224.47732747,
                            9263.15174521,  9489.22721354,  9589.89972908, 11652.39418473,
                            10660.27685547, 11886.9782006 , 16645.75742188, 21983.13709677,
                            34761.6499496 , 46306.79896763, 54998.00869456, 57206.72005208,
                            46443.28666835, 35845.1546875 , 34444.97379032, 45709.02268145,
                            45939.77148438, 57911.97051411, 60621.48880208, 49263.20917339,
                            41114.42237903, 40763.47405134, 41966.2375252 , 41435.31966146,
                            31706.10521673, 24383.68548177, 21539.25384325, 22366.26631804,
                            19804.77923177, 19650.52564264, 17600.81432292, 16949.60880796,
                            20250.71748992, 23304.53920201, 25116.90089466, 28857.57454427,
                            27499.30714466, 27763.1984375 , 30057.46994708, 27852.79284274,
                             26144.42705078]
    
    var body: some View {
        ScrollView {
            VStack {
                HStack {
                    Text("Bienvenid@ de nuevo")
                    
                    let question = questionnaire.questions[0]
                    let answer = question.answer
                    
                    Text(String(answer ?? "Caro"))
                }
                
                Text("TUS INGRESOS:")
                RoundedGreyTextField(text: $inputText)
                    .frame(width: 300, height: 40)
                    .padding()
                
                Text("PORCENTAJE A INVERTIR")
                    .padding()
                Text("Valor: \(Int(sliderValue))%")
                
                Slider(value: $sliderValue, in: 0...100, step: 1)
                    .padding()
                
                Text("POR INVERTIR:")
                Text("\(investmentAmount, specifier: "%.2f")")
                    .frame(width: 300, height: 40)
                    .padding()
                
                
                VStack(spacing: 0) {
                    
                    
                    Color.gray
                        .frame(height: 50)
                        .overlay(Text("¿Qué será de ese dinero en un mes?")
                            .foregroundColor(.white)
                            .font(.headline))
                    
                    
                    HStack {
                        
                        SquareView(value: Int(investmentAmount * 0.924), label: "Dinero inactivo por devaluación del peso")
                            .foregroundColor(Color.red) // Cambiar el color del valor a rojo

                        SquareView(value: Int(investmentAmount * (12.5 / 10)), label: "Dinero activo en fondo recomendado")
                            .foregroundColor(Color.green)

                    }
                    
                }
                .border(Color.gray, width: 1)
                .padding()
                VStack {
                    Text("Historial de cuenta")
                        .font(.title)
                        .padding(20)
                    
                    
                    GraphView(data: data)
                        .frame(height: 400)
                        .padding(25)
                    
                }
            }
        }
        
    }
}
