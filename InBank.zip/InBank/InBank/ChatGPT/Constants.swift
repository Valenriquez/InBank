//
//  Constants.swift
//  ChatGPT
//
//  Created by Manuchim Oliver on 15/03/2023.
//

import Foundation

enum Constants {
    static let OpenAIAPIKey = "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"
    
}
