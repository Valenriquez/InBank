//
//  ChatGPTApp.swift
//  ChatGPT
//
//  Created by Manuchim Oliver on 15/03/2023.
//

import SwiftUI

@main
struct ChatGPTApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
