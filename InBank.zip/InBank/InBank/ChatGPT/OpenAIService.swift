//
//  OpenAIService.swift
//  ChatGPT
//
//  Created by Manuchim Oliver on 15/03/2023.
//

import Foundation
import Alamofire
import Combine
import SwiftUI

class OpenAIService {
    let baseUrl = "https://api.openai.com/v1/"
    var isLoading: Bool = false

    func sendMessage(message: String, questionnaire: QuestionnaireModel) -> AnyPublisher<OpenAIResponse, Error> {
        // Ahora puedes acceder a questionnaire y sus propiedades, como question.answer
        let question = questionnaire.questions.first // Ejemplo: obtén la primera pregunta
        let answer = question?.answer
        
        // Continúa con tu lógica aquí, utilizando answer u otros datos de questionnaire
        let body = OpenAICompletionsBody(model: "text-davinci-003", prompt: "Vas a actuar como un asesor financiero (responde en primera persona) y llevar un conversación con un cliente. vas a responder exclusivamente con los datos que te voy a dar. Datos de los fondos: Familia Básicos: Para tus gastos diarios, semanales u objetivos de corto plazo como los útiles del próximo mes.Opciones del fondo: Alta Liquidez Digital - NTEDIG (de 0-1 año), Alta Liquidez Pesos - NTECT (de 0-1 año), Fuerte - NTEPZO (de 0-1 año).           Familia Estratégicos: Para tus objetivos de mediano a largo plazo como el ahorro para tu retiro, educación de tus hijos, etc. Opciones del fondo: Estratégico Renta Fija - NTED (3+ años), Portafolio Básico - NTE1 (3+ años), Portafolio Equilibrado - NTE2 (3+ años), Portafolio Crecimiento - NTE3 (3+ años).        Familia Especializados: Para objetivos específicos, como un viaje al extranjero. Opciones del fondo: Líquido Dólares - NTEDLS (1+ años), Estratégico Dólares - NTEDLS+ (2+ años), Empresas México - NTEIPC+ (5+ años), Empresas Sustentables - NTEESG. no completes el mensaje. Solo responde. El cliente dice: \(message). Output:", temperature: 0.6, max_tokens: 256)

        let headers: HTTPHeaders = [
            "Authorization": "Bearer \(Constants.OpenAIAPIKey)"
        ]

        return Future { [weak self] promise in
            guard let self = self else { return }
            AF.request(self.baseUrl + "completions", method: .post, parameters: body, encoder: .json, headers: headers).responseDecodable(of: OpenAIResponse.self) { response in
                switch response.result {
                case .success(let result):
                    promise(.success(result))

                case .failure(let error):
                    promise(.failure(error))
                }
            }
        }
        .eraseToAnyPublisher()
    }
}
