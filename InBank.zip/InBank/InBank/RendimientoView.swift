//
//  RendimientoView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
// Color(red: 160/255, green: 167/255, blue: 173/255)

import SwiftUI
import CoreML

struct RendimientoView: View {
    
    @State private var result = ""
    @State private var functionResults: [String: String] = [:]
    
    func calculateNextMonthNTECT() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTECT(configuration: config)
            
            let NTECTprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTECTprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTE1() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTE1(configuration: config)
            
            let NTE1prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTE1prediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTE2() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTE1(configuration: config)
            
            let NTE2prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTE2prediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTE3() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTE3(configuration: config)
            
            let NTE3prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTE3prediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTED() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTED(configuration: config)
            
            let NTEDprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEDprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTEDIG() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTEDIG(configuration: config)
            
            let NTEDIGprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEDIGprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTEDLS() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTEDLS(configuration: config)
            
            let NTEDLSprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEDLSprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTEDLSMAS() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTEDLSMAS(configuration: config)
            
            let NTEDLSMASprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEDLSMASprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTEESG() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTEESG(configuration: config)
            
            let NTEESGprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEESGprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTEIPCMAS() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTEIPCMAS(configuration: config)
            
            let NTEIPCMASprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEIPCMASprediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func calculateNextMonthNTEPZ01() -> String {
        
        do {
            let config = MLModelConfiguration()
            let model = try NTEPZ01(configuration: config)
            
            let NTEPZ01prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))
            
            result = String(round(NTEPZ01prediction.Target * 10) / 10)
        } catch {
            
        }
        
        return result
        
    }
    
    func colorForValues(value1: Double, value2: Double) -> Color {
        if value1 >= value2 {
            return Color.green
        } else {
            return Color.red
        }
    }

    
    let modelNames = ["NTE1", "NTE2", "NTE3", "NTECT", "NTED", "NTEDIG", "NTEDLS", "DTEDLS+", "DTEESG", "NTEIPC+", "NTEPZ01"]
    
    let close: [Double] = [9.7, 7.1, 8.1, 8.9, 10.5, 8.2, 12.0, 12.5, 12.2, 9.3, 9.2]

    var body: some View {
        ScrollView {
            VStack {
                Text("RENDIMIENTOS ESPERADOS")
                    .font(.custom("Arimo-VariableFont_wght", size: 25))
                    .padding(.top, 20)
                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))
                
                Text("DEL PRÓXIMO MES")
                    .font(.custom("Arimo-VariableFont_wght", size: 20))
                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))
                    .padding(.bottom, 10)
                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))

                LazyVGrid(columns: [GridItem()]) {
                    ForEach(0..<11) { index in
                        ZStack() {
                            Rectangle()
                                .fill(Color.white)
                                .border(Color.gray, width: 8)
                                .frame(width: 300, height: 350)
                            
                            RoundedRectangle(cornerRadius: 50)
                                .fill(Color.gray)
                                .frame(width: 200, height: 80)
                                .offset(y: -170)
                            
                            VStack {
                                // Textos
                                Text(modelNames[index])
                                    .offset(y: -78)
                                    .foregroundColor(.white)
                                    .font(.system(size: 30))
                                    .fontWeight(.bold)
                                
                                Text("Rendimiento")
                                    .offset(y: -35)
                                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))
                                    .font(.system(size: 25))
                                    .fontWeight(.bold)
                                
                                let value = Double(functionResults[modelNames[index], default: "8.1"]) ?? 0.0
                                let closeValue = close[index]
                                
                                Text(String(format: "%.1f%%", value))
                                    .offset(y: -30)
                                    .font(.custom("Kollektif-Bold", size: 50))
                                    .foregroundColor(colorForValues(value1: value, value2: closeValue))
                                
                                Text("Precio mes \nanterior")
                                    .offset(y: 10)
                                    .foregroundColor(Color(red: 49/255, green: 61/255, blue: 71/255))
                                    .font(.system(size: 25))
                                    .fontWeight(.bold)
                                    .multilineTextAlignment(.center)
                                
                                Text(String(format: "%.1f%%", closeValue))
                                    .offset(y: 15)
                                    .font(.custom("Kollektif-Bold", size: 50))
                                    .foregroundColor(Color(red: 160/255, green: 167/255, blue: 173/255))
                            }
                            .padding()
                        }
                        .padding(30)
                    }
                }
                .padding()

                // ...

            }
        }
        .onAppear {
                    // Cuando aparece la vista, calculamos y almacenamos los resultados en la matriz
                    functionResults["NTE1"] = calculateNextMonthNTE1()
                    functionResults["NTE2"] = calculateNextMonthNTE2()
                    functionResults["NTE3"] = calculateNextMonthNTE3()
                    functionResults["NTECT"] = calculateNextMonthNTECT()
                    functionResults["NTED"] = calculateNextMonthNTED()
                    functionResults["NTEDIG"] = calculateNextMonthNTEDIG()
                    functionResults["NTEDLS"] = calculateNextMonthNTEDLS()
                    functionResults["NTEDLS+"] = calculateNextMonthNTEDLSMAS()
                    functionResults["DTEESG"] = calculateNextMonthNTEESG()
                    functionResults["NTEIPC+"] = calculateNextMonthNTEIPCMAS()
                    functionResults["NTEPZ01"] = calculateNextMonthNTEPZ01()
                }
    }
}

struct RendimientoView_Previews: PreviewProvider {
    static var previews: some View {
        RendimientoView()
    }
}
