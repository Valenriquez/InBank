//
//  MainView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
// Color(red: 239/255, green: 41/255, blue: 67/255)

import SwiftUI

struct MainView: View {
    
    @ObservedObject var questionnaire: QuestionnaireModel

    init(questionnaire: QuestionnaireModel) {
        self.questionnaire = questionnaire
    }
    
    var body: some View {
        
        TabView(selection: .constant(1)) {
            RendimientoView()
                .tabItem {
                    Image(systemName: "chart.bar.xaxis.ascending.badge.clock")
                        .foregroundColor(.white)
                }
                .tag(0) // Asignamos el tag 0 a la primera pestaña (RendimientoView)

            StatsView(questionnaire: questionnaire)
                .tabItem {
                    Image(systemName: "person")
                        .foregroundColor(.white)
                }
                .tag(1) // Asignamos el tag 1 a la segunda pestaña (FomoView)

            ChatContentView(questionnaire: questionnaire)
                .tabItem {
                    Image(systemName: "square.fill.text.grid.1x2")
                        .foregroundColor(.white)
                }
                .tag(2) // Asignamos el tag 2 a la tercera pestaña (RecomendacionesView)
        }
    }
}
