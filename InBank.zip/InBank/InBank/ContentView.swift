//
//  ContentView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 23/09/23.
//

import SwiftUI

struct ContentView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(red: 239/255, green: 41/255, blue: 67/255)
                    .ignoresSafeArea()
                
                VStack {
                    Spacer()
                    
                    Text("¡Bienvenido!")
                        .font(.largeTitle)
                        .foregroundColor(.white)
                        .padding()
                        .fontWeight(.bold)
                    
                    TextField("Correo", text: $email)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .frame(width: 300)
                    
                    SecureField("Contraseña", text: $password)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()
                        .frame(width: 300)
                    
                    NavigationLink(destination: DatosView()) {
                        Text("Entrar")
                            .foregroundColor(Color(red: 239/255, green: 41/255, blue: 67/255))
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .font(.system(size: 15))
                            .frame(width: 80)
                            .fontWeight(.bold)
                    }
                    Spacer()
                    
                    HStack {
                        Image("banorteLogo")
                            .resizable()
                            .frame(width: 60, height: 60)
                        
                        Text("Banorte")
                            .foregroundColor(.white)
                            .padding()
                            .font(.system(size: 30))
                    }
                    
                }
            }
        }
        .navigationBarHidden(true)
    }
}
