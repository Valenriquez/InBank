//
//  DatosView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 23/09/23.
//

import SwiftUI

struct DatosView: View {
    @ObservedObject var questionnaire: QuestionnaireModel
    @State private var currentPage = 0
    let questionsPerPage = 5
    
    init() {
        // Inicializa tu modelo de datos con las preguntas aquí
        let questions = [
            Question(text: "¿Cuál es tu nombre?"),
            Question(text: "¿Cuál es tu edad?"),
            Question(text: "Sexo", options: ["Masculino", "Femenino", "Prefiero no decir"]),
            Question(text: "País"),
            Question(text: "Salario mensual"),
            Question(text: "¿Cuál es tu nivel de experiencia en inversiones?", options: ["Principiante", "Intermedio", "Avanzado"]),
            Question(text: "¿Tienes alguna deuda significativa actualmente?", options: ["Si", "No"]),
            Question(text: "¿Qué porcentaje de tus ahorros destinarás a tu inversión?", options: ["Menos del 25%", "Entre 25% y 50%", "Entre 50% y 75%", "Más del 75%"]),
            Question(text: "¿Cuál es tu principal objetivo?", options: ["Tener un fondo de emergencia\nTener un respaldo para imprevistos", "Construir mi patrimonio\nIncrementar mi ahorro para comprar una vivienda, iniciar un negocio, etc.", "Invertir para mi retiro\nMantener un buen estilo de vida para el futuro"]),
            Question(text: "¿Cuál es tu actividad económica?", options: ["Comerciante", "Profesionista independiente", "Profesionista asalariado", "Jubilado o pensionado"]),
            Question(text: "¿Cuál es tu último grado de estudios?", options: ["Sin escolaridad", "Primaria", "Secundaria", "Preparatoria", "Técnica/Comercial", "Licenciatura", "Maestría/Doctorado"]),
            Question(text: "¿El dinero que invertirás de dónde proviene?", options: ["Pensión", "Sueldo", "Utilidad de negocio propio", "Venta de inmueble, herencia, etc."]),
            Question(text: "¿Cuánto tiempo esperarías para recibir las ganancias de tu inversión?", options: ["Menos de 60 días", "Seis meses", "Dentro de uno o dos años", "Dentro de tres años o más"]),
            Question(text: "¿Has invertido en alguna de estas opciones anteriormente?", options: ["Fondos de Inversión de Renta Fija", "Fondos de Inversión de Renta Variable", "Mercado de Renta Fija", "Mercado Accionario", "Ninguna de las anteriores"]),
            Question(text: "¿Cuál es tu grado de tolerancia al riesgo y la pérdida?", options: ["Prefiero no tener pérdidas, aunque mi ganancia no sea tan alta", "Acepto pérdidas no tan grandes, siempre y cuando obtenga mejores rendimientos a mediano plazo", "Acepto cambios negativos en el valor de mis inversiones, siempre y cuando éstas se recuperen y terminen generando un mejor rendimiento."]),
            Question(text: "Perfil", options: ["Arriesgado", "Conservador"]),
        ]
        self.questionnaire = QuestionnaireModel(questions: questions)
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ForEach(currentPage * questionsPerPage..<min((currentPage + 1) * questionsPerPage, questionnaire.questions.count), id: \.self) { index in
                    QuestionView(questionnaire: questionnaire, questionIndex: index)
                }
            }
        }
        
        VStack {
            // Muestra la barra de progreso basada en el progreso actual
            ProgressView(value: Double(currentPage + 1) / Double((questionnaire.questions.count + questionsPerPage - 1) / questionsPerPage))
                .padding()
            
            HStack {
                // Botón para retroceder
                Button(action: {
                    if currentPage > 0 {
                        currentPage -= 1
                    }
                }) {
                    Image(systemName: "arrow.left.circle")
                        .padding()
                        .font(.system(size: 30))
                }
                
                Spacer()
                
                // Botón para avanzar
                Button(action: {
                    if currentPage < (questionnaire.questions.count + questionsPerPage - 1) / questionsPerPage - 1 {
                        currentPage += 1
                    }
                }) {
                    Image(systemName: "arrow.right.circle")
                        .padding()
                        .font(.system(size: 30))
                }
            }
            
            if currentPage == 3 {
               // NavigationLink(destination: AnswersView(questionnaire: questionnaire)) {
                NavigationLink(destination: MainView(questionnaire: questionnaire)) {
                    HStack {
                        Image(systemName: "checkmark.circle")
                            .font(.system(size: 30))
                        Text("Terminado")
                    }
                }
            }
        }
    }
}



