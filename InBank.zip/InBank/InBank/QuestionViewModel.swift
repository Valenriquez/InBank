//
//  QuestionViewModel.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
//

import Foundation

struct Question {
    let text: String
    var answer: String? // Respuesta abierta
    var options: [String]? // Opciones de respuesta múltiple
}

class QuestionnaireModel: ObservableObject {
    @Published var questions: [Question]
    
    init(questions: [Question]) {
        self.questions = questions
    }
}

