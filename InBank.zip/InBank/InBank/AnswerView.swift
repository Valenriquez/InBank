//
//  AnswerView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
//

import SwiftUI

struct AnswerView: View {
    @ObservedObject var questionnaire: QuestionnaireModel
    
    var body: some View {
        VStack {
            Text("Respuestas:")
                .font(.title)
                .padding()
            
            List {
                ForEach(questionnaire.questions.indices, id: \.self) { questionIndex in
                    if let answer = questionnaire.questions[questionIndex].answer {
                        VStack(alignment: .leading) {
                            Text("Pregunta \(questionIndex + 1):")
                                .font(.headline)
                            
                            Text(answer)
                        }
                    }
                }
            }
        }
    }
}
