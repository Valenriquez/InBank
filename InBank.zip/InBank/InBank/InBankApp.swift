//
//  InBankApp.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 23/09/23.
//

import SwiftUI

@main
struct InBankApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
