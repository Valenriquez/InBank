import SwiftUI
import CoreML

struct ModelView: View {
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    @State private var showingAlert = false

    var body: some View {
        VStack {
            Text("Tap to predict (NTECT)")
                .onTapGesture {
                    calculateNextMonthNTECT()
                }.padding()
            
            Text("Tap to predict (NTE1)")
                .onTapGesture {
                    calculateNextMonthNTE1()
                }.padding()
        }
        .padding()
        .alert(isPresented: $showingAlert) {
            Alert(title: Text(alertTitle), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }

    func calculateNextMonthNTECT() {
        do {
            let config = MLModelConfiguration()
            let model = try NTECT(configuration: config)

            let NTECTprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTECT: "
            alertMessage = String(NTECTprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTE1() {
        do {
            let config = MLModelConfiguration()
            let model = try NTE1(configuration: config)

            let NTE1prediction = try model.prediction(Close: Double(9.72), SMA: Double(9.4), EMA: Double(9.49), MACD: Double(-0.42), RSI: Double(1.156), Upper_band: Double(9.876), Lower_band: Double(8.93), Close__1_: Double(9.29), Close__2_: Double(9.347), lnClose: Double(2.274), lnClose__1_: Double(2.229), lnClose__2_: Double(2.235))

            alertTitle = "The prediction of the model NTE1: "
            alertMessage = String(NTE1prediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTE2() {
        do {
            let config = MLModelConfiguration()
            let model = try NTE2(configuration: config)

            let NTE2prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTE2: "
            alertMessage = String(NTE2prediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTE3() {
        do {
            let config = MLModelConfiguration()
            let model = try NTE3(configuration: config)

            let NTE3prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTE3: "
            alertMessage = String(NTE3prediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTED() {
        do {
            let config = MLModelConfiguration()
            let model = try NTED(configuration: config)

            let NTEDprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTED: "
            alertMessage = String(NTEDprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTEDIG() {
        do {
            let config = MLModelConfiguration()
            let model = try NTEDIG(configuration: config)

            let NTEDIGprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTEDIG: "
            alertMessage = String(NTEDIGprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTEDLS() {
        do {
            let config = MLModelConfiguration()
            let model = try NTEDLS(configuration: config)

            let NTEDLSprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTEDLS: "
            alertMessage = String(NTEDLSprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTEDLSMAS() {
        do {
            let config = MLModelConfiguration()
            let model = try NTEDLSMAS(configuration: config)

            let NTEDLSMASprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTEDLSMAS: "
            alertMessage = String(NTEDLSMASprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTEESG() {
        do {
            let config = MLModelConfiguration()
            let model = try NTEESG(configuration: config)

            let NTEESGprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTEESG: "
            alertMessage = String(NTEESGprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTEIPCMAS() {
        do {
            let config = MLModelConfiguration()
            let model = try NTEIPCMAS(configuration: config)

            let NTEIPCMASprediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTEIPCMAS: "
            alertMessage = String(NTEIPCMASprediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
    func calculateNextMonthNTEPZ01() {
        do {
            let config = MLModelConfiguration()
            let model = try NTEPZ01(configuration: config)

            let NTEPZ01prediction = try model.prediction(Close: Double(7.127177), SMA: Double(7.300590), EMA: Double(7.245473), MACD: Double(0.075015), RSI: Double(0.992191), Upper_band: Double(7.586486), Lower_band: Double(7.014695), Close__1_: Double(7.346145), Close__2_: Double(7.147677), lnClose: Double(1.963915), lnClose__1_: Double(1.994176), lnClose__2_: Double(1.966787))

            alertTitle = "The prediction of the model NTEPZ01: "
            alertMessage = String(NTEPZ01prediction.Target)
        } catch {
            alertTitle = "Error"
            alertMessage = "Sorry, there was a problem calculating."
        }

        showingAlert = true
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ModelView()
    }
}
