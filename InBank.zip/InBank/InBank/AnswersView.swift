//
//  AnswersView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 24/09/23.
//

import SwiftUI

struct AnswersView: View {
    @ObservedObject var questionnaire: QuestionnaireModel

    init(questionnaire: QuestionnaireModel) {
        self.questionnaire = questionnaire
    }

    var body: some View {
        VStack {
            // Mostrar las respuestas del cuestionario en un Text o cualquier otro componente de UI
            Text("Respuestas del Usuario:")
                .font(.headline)
            
            // Puedes acceder a las respuestas del cuestionario a través del modelo de datos
            ForEach(questionnaire.questions.indices, id: \.self) { index in
                let question = questionnaire.questions[index]
                if let answer = question.answer {
                    Text("\(answer)")
                }
            }
        }
    }
}
