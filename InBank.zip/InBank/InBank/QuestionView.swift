//
//  QuestionView.swift
//  InBank
//
//  Created by Carolina Nicole González Leal on 23/09/23.
//

import SwiftUI

struct QuestionView: View {
    @ObservedObject var questionnaire: QuestionnaireModel
    var questionIndex: Int
    
    var body: some View {
        VStack {
            Text(questionnaire.questions[questionIndex].text)
                .font(.headline)
            
            if let options = questionnaire.questions[questionIndex].options {
                VStack(alignment: .leading) {
                    ForEach(options, id: \.self) { option in
                        Button(action: {
                            questionnaire.questions[questionIndex].answer = option
                        }) {
                            HStack {
                                Image(systemName: questionnaire.questions[questionIndex].answer == option ? "largecircle.fill.circle" : "circle")
                                    .foregroundColor(questionnaire.questions[questionIndex].answer == option ? .blue : .gray)
                                    .onTapGesture {
                                        questionnaire.questions[questionIndex].answer = option
                                    }
                                Text(option)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            } else {
                // Pregunta de respuesta abierta
                TextField("Escribe tu respuesta", text: Binding(
                    get: {
                        questionnaire.questions[questionIndex].answer ?? ""
                    },
                    set: {
                        questionnaire.questions[questionIndex].answer = $0
                    }
                ))
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .frame(width: 300)
            }
        }
    }
}
